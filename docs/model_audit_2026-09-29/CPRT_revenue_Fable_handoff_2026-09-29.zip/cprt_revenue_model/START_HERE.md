# Copart revenue model: audited scenario handoff

Start with RESEARCH_STATE.md, docs/pitch_audit_2026-09-29/README.md,
then docs/model_audit_2026-09-29/FABLE_HANDOFF.md and AUDIT.md.
Publication refreshed 30 September: no established measurable forecast error
linked to an observable near-term catalyst. Reporting windows are not catalysts
without an identifiable surprise. Preserve this concern in the pitch.
Architecture and arithmetic checked; causal forecast evidence remains incomplete.
Scope is legacy service revenue, with separately identified purchased/acquisition overlays.
This package is for an editable scenario workbook, not an approved investment forecast.

Run python3 REPRODUCE.py from this directory. Python 3.9+; standard library only.
Uses saved dated evidence; raw licensed reports and private workbooks are excluded.
Do not run predecessor model mains or treat archived fixture outputs as forecasts.
FILE_MANIFEST.json lists all packaged files and hashes, excluding itself.
